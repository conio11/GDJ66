package javaTest; // 19번 문제 // 0123

public class Main19 {
	public static void main(String[] args){
    	int i;
        int a[] = {0,1,2,3};
        for(i=0; i<4; i++){
        	System.out.print(a[i] + "");  // 0123
        }
     }
 }

